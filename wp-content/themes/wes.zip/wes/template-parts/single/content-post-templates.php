<?php 
$Modules = new Modules();
$Modules->modules_section(get_the_ID(), true);
?>