<?php get_template_part('template-parts/section/content', 'banner'); ?>
<article id="post-<?php the_ID() ?>" role="article">
	<?php the_content() ?>
</article>