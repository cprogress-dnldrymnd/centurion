<?php
$Theme_Options = new Theme_Options;
$DisplayData = new DisplayData;
$SVG = new SVG;

?>


<div class="top-bar background-black ">
  <div class="container">
    <div class="row row-main justify-content-center">
      <div class="col py-3 d-none">
        <div class="row flex-nowrap gy-3 align-items-center ">
          <?php
          if ($Theme_Options->landing_top_bar_logo) {
            echo '<div class="col-auto d-none d-sm-block">';
            $DisplayData->image(
              array(
                'image_id' => $Theme_Options->landing_top_bar_logo
              )
            );
            echo '</div>';

          }

          if ($Theme_Options->landing_top_bar_text) {
            echo '<div class="col">';

            $DisplayData->description(
              array(
                'description' => $Theme_Options->landing_top_bar_text
              )
            );
            echo '</div>';

          }
          ?>
        </div>
      </div>
      <div class="col-auto col-buttons">
        <div class="button-group-box h-100 d-flex justify-content-end">
          <div class="button-box button-link h-100 text-end me-0">
            <a href="<?= $Theme_Options->email_address_url ?>" class="h-100 w-100 email-icon">
              <span class="icon"><?= $SVG->email ?></span>
              <span class="text d-none d-lg-block"><?= $Theme_Options->email_address_text ?></span>
			<span class="text d-block d-lg-none">Email us</span>
				
            </a>
          </div>
          <div class="button-box button-accent h-100 m-0 text-end">
            <a href="<?= $Theme_Options->phone_number_url ?>" class="h-100 w-100">
              <span class="icon"><?= $SVG->phone ?></span>
              <span class="text">Call us now</span>
            </a>
          </div>

        </div>
      </div>
    </div>
  </div>
</div>