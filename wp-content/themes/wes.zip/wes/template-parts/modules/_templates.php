<?php 
$Modules = new Modules();
$Modules->modules_section($module['template'], true);
?>