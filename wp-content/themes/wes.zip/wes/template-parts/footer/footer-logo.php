<?php

$Theme_Options = new Theme_Options;
$DisplayData = new DisplayData;
$footer_logos = $Theme_Options->footer_logos;
?>
<section class="footer-logos">
	<div class="container">
		<div class="row">
			<div class="col-md-3 col-4 background-gray-3">
				<div class="column-holder d-flex align-items-center h-100 sm-padding">
					<?= $Theme_Options->logo ?>
				</div>
			</div>

			<?php if ($footer_logos) { ?>
				<div class="col-md-9 col-8">
					<div class="column-holder sm-padding">
						<div class="logo-slider">
							<div class="swiper mySwiper-logoSwiperFooter">
								<div class="swiper-wrapper text-center align-items-center">
									<?php foreach ($footer_logos as $footer_logo) { ?>
										<div class="swiper-slide">
											<?php
											$DisplayData->image(
												array(
													'image_id' => $footer_logo,
													'size'     => 'medium'
												),
											);
											?> </div>
									<?php } ?>
								</div>
							</div>
						</div>
					</div>
				</div>
			<?php } ?>

		</div>
	</div>
</section>